#!/usr/bin/env python3
"""Static HTML packaging hints. Never executes input; not an offline/security proof."""
import argparse
import json
import re
from html.parser import HTMLParser
from pathlib import Path

class Inventory(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.resources = []
        self.inline_scripts = 0
        self.script_depth = 0
        self.script_text = []
    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == 'script':
            self.script_depth += 1
            self.inline_scripts += 'src' not in a
        keys = {'script': ['src'], 'img': ['src', 'srcset'], 'link': ['href'],
                'audio': ['src'], 'video': ['src', 'poster'], 'source': ['src', 'srcset'],
                'iframe': ['src'], 'object': ['data'], 'embed': ['src'], 'input': ['src']}
        for key in keys.get(tag, []):
            if a.get(key):
                value = a[key]
                self.resources.append({'tag': tag, 'attribute': key,
                    'value': value[:160], 'embedded': value.startswith(('data:', '#'))})
    def handle_endtag(self, tag):
        if tag == 'script': self.script_depth = max(0, self.script_depth - 1)
    def handle_data(self, data):
        if self.script_depth: self.script_text.append(data)

def audit(path, budget=None):
    raw = Path(path).read_bytes()
    text = raw.decode('utf-8-sig')
    inv = Inventory()
    inv.feed(text)
    patterns = {
        'fetch_calls': r'\bfetch\s*\(',
        'xhr': r'\bXMLHttpRequest\b',
        'dynamic_imports': r'\bimport\s*\(',
        'static_imports': r'\bimport\s+(?:[^;\n]*?\s+from\s*)?[\"\']',
        'workers': r'\b(?:SharedWorker|Worker)\s*\(',
        'websockets': r'\bWebSocket\s*\(',
        'wasm': r'\bWebAssembly\b',
        'css_urls': r'url\s*\(',
        'css_imports': r'@import\b',
        'source_maps': r'sourceMappingURL\s*=',
        'base64_markers': r';base64,',
    }
    hints = {k: len(re.findall(v, text)) for k, v in patterns.items()}
    urls = sorted(set(re.findall(r'https?://[^\s\"\'<>`\\)]+', text)))
    return {'file': str(path), 'bytes': len(raw), 'MiB': round(len(raw)/1048576, 4),
            'budget_bytes': budget, 'within_budget': None if budget is None else len(raw) <= budget,
            'inline_script_count': inv.inline_scripts,
            'inline_script_utf8_bytes': len(''.join(inv.script_text).encode('utf-8')),
            'resource_attributes': inv.resources, 'static_hints': hints,
            'literal_url_count': len(urls), 'literal_urls_first_50': [u[:200] for u in urls[:50]],
            'caveat': 'Heuristic only: unused library loaders can trigger hints; computed URLs can be missed. Verify network and offline behavior in a clean browser.'}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('html')
    p.add_argument('--max-bytes', type=int)
    a = p.parse_args()
    if a.max_bytes is not None and a.max_bytes < 0: p.error('--max-bytes must be nonnegative')
    try: result = audit(a.html, a.max_bytes)
    except (OSError, UnicodeError) as e: p.exit(1, f'Cannot read UTF-8 HTML: {e}\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 2 if result['within_budget'] is False else 0

if __name__ == '__main__':
    raise SystemExit(main())
